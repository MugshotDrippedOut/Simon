# ConsoleSnake
 Snake game in your windows, linux or macOS console
