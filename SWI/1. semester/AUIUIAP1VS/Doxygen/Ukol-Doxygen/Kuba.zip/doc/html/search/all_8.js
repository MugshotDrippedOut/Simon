var searchData=
[
  ['update_5fcoors_0',['update_coors',['../classmain_1_1_snake.html#a50de7b69fa94bbb447b92e56fb4961bb',1,'main::Snake']]]
];
