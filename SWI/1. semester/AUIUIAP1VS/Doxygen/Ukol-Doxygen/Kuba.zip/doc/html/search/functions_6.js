var searchData=
[
  ['set_5fnormal_5fterm_0',['set_normal_term',['../classgetch_1_1_k_b_hit.html#a4fe051102f7088638da562d8b3a41e82',1,'getch::KBHit']]],
  ['set_5fskins_1',['set_skins',['../classmain_1_1_snake.html#a05f34c7a2c685c2768c5af35f5c9f711',1,'main::Snake']]]
];
