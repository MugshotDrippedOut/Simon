var searchData=
[
  ['getch_0',['getch',['../namespacegetch.html',1,'']]]
];
