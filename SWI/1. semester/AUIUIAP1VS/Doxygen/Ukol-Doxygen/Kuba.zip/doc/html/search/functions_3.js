var searchData=
[
  ['getarrow_0',['getarrow',['../classgetch_1_1_k_b_hit.html#a15d7d462d199a30b49e48efeb45ad2b7',1,'getch::KBHit']]],
  ['getch_1',['getch',['../classgetch_1_1_k_b_hit.html#ac79ada9c8c5b31e5963ae9e2d7638d21',1,'getch::KBHit']]]
];
