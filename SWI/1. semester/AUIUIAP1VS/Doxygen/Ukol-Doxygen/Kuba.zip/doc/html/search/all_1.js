var searchData=
[
  ['alive_0',['alive',['../classmain_1_1_snake.html#aa81eff4aacf994a053f157b5cecab937',1,'main::Snake']]]
];
