#include <stdio.h>


/**
 * @brief Sorts the given array using bubble sort algorithm for a specific number of iterations.
 * 
 * @param arr Pointer to the first element in the array to be sorted.
 * @param size Size of the array.
 * @param i Number of iterations to perform. 
 */
void bubble_sort(int *arr, int size, int i) {
    int a, j;
    for (a = 0; a < i; a++) {
        for (j = 0; j < size-a-1; j++) {
            if (arr[j] > arr[j+1]) {
                int medzi = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = medzi;
            }
        }
    }
}

int main() {

    int my_array[] = {9, 4, 3, 2, -1, -9};
    int n = sizeof(my_array)/sizeof(my_array[0]);
    int num_iterations = 3;

    bubble_sort(my_array, n, num_iterations);

    printf("Sorted array: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", my_array[i]);
    }

    return 0;
}