#include <stdio.h>

int main() {
   // Example code that has been commented out.
//   int i = 5;
//   int arr[]={1,2,3};
//   printf("%d", sizeof(arr));
//   printf("\n");
//   int arr2[10];
//   int j;
//   for(j=0; j<sizeof(arr2)/sizeof(arr[0]);j++)
//   {
//      arr2[j] = j*2;
//      printf("%d", arr2[j]);
//      printf(" ");
//   }
//   printf("\n");
//   printf("%d", sizeof(arr2)/sizeof(arr2[0]));
//   printf("\n");

   // Declare and initialize a character variable 'b' to 6 and a character pointer 'uka' to point to 'b'.
   char b = 6;
   char *uka = &b;

   // Print the memory address of 'b' and the memory address stored in 'uka'.
   printf("%p\n",&b);
   printf("%p\n",&uka);

   // Call the function GetSum() with an argument of 10, which returns the sum of all even numbers between 0 and 10.
   int GetSum();
   int velkostPola = 10;
   int sum = GetSum(velkostPola);
   printf("\nSum párnych čísiel je: ");
   printf("%d",sum);

   // Declare an integer array 'arr3' of size 'velkostPola' and fill it with values from 0 to 9.
   int arr3[velkostPola];
   for(int j=0; j<sizeof(arr3)/sizeof(arr3[0]);j++)
   {
      arr3[j] = j;
   }

   // Call the function GetSum1() with 'arr3' and its length as arguments, which returns the sum of all elements in 'arr3'.
   int GetSum1();
   int sum1 = GetSum1(arr3, sizeof(arr3)/sizeof(arr3[0]));
   printf("\nSum všetkých čísiel je: ");
   printf("%d",sum1);
   return 0;

   // Example code that has been commented out.
   int arr4[] = {1,2,3,4};
   printf("\n%d",sizeof(arr4));
   printf("\n%d",*arr4);
   printf("\n%d",arr4);
   printf("\n%d",&arr4[0]);
}

// Function 'GetSum()' takes an integer 'a' and returns the sum of all even numbers between 0 and 'a'.
int GetSum(int a){
   int arr3[a];
   for(int j=0; j<sizeof(arr3)/sizeof(arr3[0]);j++)
   {
      arr3[j] = j;
   }
   int k;
   int sum=0;
   for(k=0; k<sizeof(arr3)/sizeof(arr3[0]); k++)
   {
      if(arr3[k]%2==1){
      sum = arr3[k] + sum;
      }
   }
   return sum;
}

// Function 'GetSum1()' takes an integer array 'arr' and its length 'length' as arguments and returns the sum of all elements in 'arr'.
int GetSum1(int arr[],int lenght){
   int sum=0;

   int *a;
   for(int i=0; i<lenght; ++i)
   {
      a = (&arr[0]+i);
      sum = *a + sum;
   }
   return sum;
}

