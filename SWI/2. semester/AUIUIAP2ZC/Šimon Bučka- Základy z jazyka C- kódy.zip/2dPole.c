#include <stdio.h>


/*int sumSude(int *arr){
    int i,j;
    int sum=0;    
    for(i=0; i <= 3;i++)
    {
        for(j=0; j <= 2;j++)
        {
            if(arr[i][j]%2==0){
            
                sum= arr[i][j]+sum;
            }
        }
    }
    return sum;
}*/

int main(){
    int mat[4][3] ={{1,2,3},{4,77,77},{7,8,9},{10,77,12}};

    int desat = mat[3][0];
    //printf("%d",desat);
    int i,j;
    for(i=0; i <= 3;i++)
    {
        for(j=0; j <= 2;j++)
        {
        printf("%d",mat[i][j]);
        printf("|");        
        }
    printf("\n");    
    }

    int sum=0;    
    for(i=0; i <= 3;i++)
    {
        for(j=0; j <= 2;j++)
        {
            if(mat[i][j]%2==0){
            
                sum= mat[i][j]+sum;
            }
        }
    }
    printf("%d\n",sum); 
    //int sum1= sumSude(mat);
    int k=0;
    for(i=0; i <= 3;i++)
    {
        for(j=0; j <= 2;j++)
        {
            if(mat[i][j]==77){
            
                k++;
            }
        }
    }

    int vKtoromRiadku[4];
    for(i=0; i <= 3;i++)
    {
        for(j=0; j <= 2;j++)
        {
            if(mat[i][j]==77){
            
                vKtoromRiadku[i]=1;
                
                break;
            }
        }
    }
    for(int a; a<=3;a++){
        if(vKtoromRiadku[a]==1){
            printf("%s","V riadku s hodnotou: "); 
            printf("%d",a);
            printf("%s"," sa nachadza 77\n");

        }
    }
    return 0;
}

