#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

/**
* @brief Struct containing information about a student.
*/
typedef struct{
    char name[10]; ///< The name of the student.
    char surname[10]; ///< The surname of the student.
    int birthYear; ///< The birth year of the student.
} Student;

/**
* @brief Struct containing two integers.
*/
typedef struct{
    int number; ///< The first integer.
    int anotherNumber; ///< The second integer.
} Ahoj;


/**
 * @brief Prints the details of a student object.
 *
 * This function prints the name, surname and birth year
 * of a given student object to the console.
 *
 * @param s The student object to print.
 */
void printStudent(Student s){
    printf("%s,%s,%d\n",s.name,s.surname,s.birthYear);
}

/**
 * Increases the birth year of a given student by setting it to 1950.
 *
 * @param localS The student whose birth year will be increased.
 * @return The same student with an updated birth year.
 */
Student makeStudentOlder(Student localS){
    localS.birthYear=1950;
    return localS;
}

/*
Student filteOnlyMature(Student students[],size_t size){
    Student matureStudents[size];
    int numberOfMatureStudents=0;
    for(int i; i <size; i++){

        if(students[i].birthYear<2003){
            matureStudents[numberOfMatureStudents]=students[i];
            numberOfMatureStudents++;
        }
    }
    return *matureStudents;
}
*/

// This function takes an array of Student structures and its size
Student *filterOnlyMature(Student students[], int size){
    // Allocate memory for an empty temporary array of Students
    Student *tempArr = malloc(0);
    // Initialize variables to keep track of the current size of the array
    int currentSize = 0;
    // Iterate through each element in the original array
    for (int i = 0; i < size; ++i) {
        // Check if the birth year of the student is less than or equal to 2004
        if (students[i].birthYear <= 2004){
            // If so, reallocate memory for the temporary array with enough space for another Student structure
            tempArr = realloc(tempArr, sizeof(Student) + currentSize);
            // Insert the current student into the next available position in the temporary array
            tempArr[currentSize/sizeof(Student)] = students[i];
            // Update the current size of the temporary array
            currentSize += sizeof(Student);
        }
    }
    // Return a pointer to the newly created array
    return tempArr;
}


int main(){

    Ahoj a={4,5}; // Create an instance of the struct Ahoj with members 4 and 5

    Student s; // Create an instance of the struct Student
    strcpy(s.name,"Adam"); // Set the name member of s to "Adam"
    strcpy(s.name,"Ulrich"); // Overwrite the name member of s to "Ulrich" (previous line has no effect)
    s.birthYear=1996; // Set the birthYear member of s to 1996


    char arr[40] = {'A','B','C','D', }; // Create a character array with size 40 and initialize its first four elements to 'A', 'B', 'C', and 'D'
    arr[0]; // Access the first element of the array (does nothing)


    Student sk = {"kolo","pogo",2006}; // Create an instance of the struct Student and initialize its members
    Student sk2 = {"Abraham","gono",1988}; // Same as above
    Student sk3 = {"Milan","novak",2001}; // Same as above
    Student sk4 = {"Kristof","povak",2010}; // Same as above
    Student students[4] = {sk,sk2,sk3,sk4}; // Create an array of Students with the previous instances

    for(int i; i<10;i++){ // Loop 10 times
        printf("%d,",sk.name[i]); // Print the ASCII value of the i-th character of the name member of sk
    }
    printf("\n%d\n",sizeof(sk2)); // Print the size in bytes of sk2

    for(int i = 0; i <sizeof(students)/sizeof(Student); ++i){ // Loop through the students array
        printStudent(students[i]); // Call a function to print the i-th student in the array
    }



    Student starsi = makeStudentOlder(sk); // create a new student instance 'starsi' and call function 'makeStudentOlder' passing in 'sk' as an argument to make it older
    printStudent(sk); // print the student 'sk' to the console
    printf("\n"); // print a newline character to the console
    printStudent(starsi); // print the student 'starsi' to the console
    size_t size = sizeof(students)/sizeof(Student); // calculate the number of elements in array 'students' using their memory sizes and store it in 'size'
    int lenght =sizeof(students); // calculate the total memory size of array 'students' and store it in 'lenght'
    /*
    //dynamicke pole studentu, vratit ukazatel na studentu 
    Student * filteOnlyMature(Student students[],size_t size){
    student arr[size/sizeof(student)];
    //realloc zobere dynamicky allocovane pole
    }*/
    printf("\n");

    // Calls the function filterOnlyMature, which returns a pointer to an array of students that are older than 18:
    Student *mature = filterOnlyMature(students, sizeof(students)/sizeof(Student));
    // Prints out the first two (out of however many there are) students from the filtered array:
    for (int i = 0; i < 2; ++i) {
        printStudent(mature[i]);
    }
    return 0;
}