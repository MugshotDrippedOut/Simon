//s vyuzitim struktury linker list vytvor rekurzivny funkci ktora bude vracet skalarny soucet listu
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

//vytvorenie prvého linkerListu 
/**
* A singly linked list node that stores an integer value and a pointer to the next node.
*/
typedef struct node {
    int data;           // The integer value stored in this node
    struct node* next;  // Pointer to the next node in the list (NULL if this is the last node)
} node;

//vytvorenie druhého linkerListu
typedef struct node1 {
    int data;
    struct node1* next;
} node1;

//Funkcia pre pridávanie čísiel do prvého linkerListu
node* NodeInsert(int value, struct node* prva){
    node* new_node = (node*)malloc(sizeof(node));
    new_node->data = value;
    new_node->next = prva;
    return new_node;
}

//Funkcia pre pridávanie čísiel do druhého linkerListu
node1* Node1Insert(int value, struct node1 *prva){
    node1* new_node = (node1*)malloc(sizeof(node1));
    new_node->data = value;
    new_node->next = prva;
    return new_node;
}

//Funkcia pre skalárny súčin dvoch Linker Listov
/**
* This function calculates the scalar product of two vectors represented
* as linked lists. The scalar product of two vectors is the sum of the
* products of corresponding components of the two vectors.
*
* @param n - pointer to the first linked list representing a vector
* @param n1 - pointer to the second linked list representing a vector
* @return the scalar product of the two vectors
*/
int Scalar(node* n, node1* n1) {
    int sum = 0; // Initialize the sum to zero

    // Iterate over both linked lists until we reach the end of at least one of them
    while (n != NULL && n1 != NULL) {
        sum += n->data * n1->data; // Add the product of corresponding components to the sum
        n = n->next; // Move to the next component in the first vector
        n1 = n1->next; // Move to the next component in the second vector
    }

    return sum; // Return the final sum
}

//Funkcia pre skalárny súčin dvoch Linker Listov podla Ulricha
/**
*    This function returns scalar of two vectors
*    (u1,u2) . (v1,v2) = u1v1 + u2v2
*
*    @param n - first linked list to multiply 
*    @param n1 - second linked list to multiply 
*    @return number - scalar multiplication
*/
int ScalarUlrich(node *n,node1 *n1){
    if (n == NULL||n1==NULL){
        return 0;
    }
    return n->data * n1->data + ScalarUlrich(n->next,n1->next);
}

//Funkcia pre skalárny súčin dvoch Linker Listov Taylerovou rekurziou
int ScalarTaylor(node *n,node1 *n1,int sum){
    if (n == NULL||n1==NULL) {
        return(sum);
    } else {
        sum += ((n->data)*(n1->data));
        ScalarTaylor(n->next,n1->next,sum);
    }
}

//Funkcia pre vypísanie linker listu
/**
*    This function prints the elements of a linked list recursively.
*    
*    @param n - pointer to the head of the linked list to be printed
*    @return void
*/
void print_list(node* n) {
    if (n == NULL) {        // if the current node is NULL, we have reached the end of the list
        printf("STOP\n");   // so we print "STOP" to indicate that we have finished printing the list
    } else {
        printf("%d ", n->data);             // otherwise, we print the data stored in the current node
        print_list(n->next);                // and call the print_list() function again with the next node in the list
    }
}

int main() {

    node* prva = NULL; // pointer to the first element of a singly linked list
    // initialize the linked list with numbers: 8, 4, 3, and 11 using NodeInsert function
    prva = NodeInsert(8, prva);
    prva = NodeInsert(4, prva);
    prva = NodeInsert(3, prva);
    prva = NodeInsert(11, prva);

    print_list(prva); // print the linked list using print_list function

    node1* prva1 = NULL; // pointer to the first element of another singly linked list
    // initialize the linked list with numbers: 10, 5, 15, and 5 using Node1Insert function
    prva1 = Node1Insert(10, prva1);
    prva1 = Node1Insert(5, prva1);
    prva1 = NodeInsert(15, prva1);
    prva1 = NodeInsert(5, prva1);

    print_list(prva1); // print the linked list using print_list function

    // calculate the scalar product of two lists using Scalar, ScalarUlrich, and ScalarTaylor functions
    int sum = Scalar(prva,prva1); 
    int sumUlrich = ScalarUlrich(prva,prva1);
    int sumTaylor = ScalarTaylor(prva,prva1,0);

    // print the results of scalar product calculation
    printf("\n%d Scalar",sum);
    printf("\n%d ScalarUlrich",sumUlrich);
    printf("\n%d ScalarTaylor",sumTaylor);

    return 0;
}
