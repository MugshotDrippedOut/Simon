#include <stdio.h>
#include <stdlib.h>
#include "memory.h"
#include "string.h"

/**
* @brief Macro defining the length of an array
*/
#define LEN_ARR 10

/**
* @struct Res
* @brief A struct containing a pointer to an integer array and its new size after certain operations.
*/
typedef struct {
    int *novepole; ///< Pointer to the new integer array
    size_t novaVelikost; ///< The new size of the integer array
} Res;


/**
* @param arr - dynamicky alokovane pole na halde
* @param length - delka puvodniho pole
* @return * ukazatel na nove misto v pameti
*/
Res removeLast(int *arr, int length) {
    size_t sizeToCopy = sizeof(int) * (length - 1);
    // nachystej o jedno mensi prostor
    int *novaPlastelina = malloc(sizeToCopy);
    // nacpi o jedno mensi do noveho prostoru
    memcpy(novaPlastelina, arr, sizeToCopy);
    // vrat adresu noveho prostoru, abych s nim mohl venku pracovat
    //return novaPlastelina;
    Res ret;
    ret.novepole = novaPlastelina;
    ret.novaVelikost = length - 1;
    return ret;
}

/**
* Removes the middle element from an array of integers.
*
* @param arr The input integer array.
* @param length The length of the input array.
*
* @return A struct containing the new integer array and its length after removing the middle element.
*/
Res removeMiddle(int *arr, int length) {
    int middle = length / 2;
    int *novaPlastelina = malloc(sizeof(int) * (length - 1));
    memmove(novaPlastelina, arr, middle * sizeof(int));
    memmove(novaPlastelina + middle, arr + middle + 1, (length - middle - 1) * sizeof(int));
    Res ret;
    ret.novepole = novaPlastelina;
    ret.novaVelikost = length - 1;
    return ret;
}


int main() {

    int *ukH = malloc(sizeof(int) * LEN_ARR);
    for (int i = 0; i < LEN_ARR; ++i) {
        ukH[i] = i + 1;
        //printf("%d,",ukH[i]);
    }

    Res r = removeMiddle(ukH, LEN_ARR);

    for (int i = 0; i < r.novaVelikost; ++i) {
        printf("%d,", r.novepole[i]);
    }

    free(r.novepole);

    if (ukH == NULL) {
        printf("allocation failed");
        exit(1);
    }
    free(ukH);
    return 0;
}
