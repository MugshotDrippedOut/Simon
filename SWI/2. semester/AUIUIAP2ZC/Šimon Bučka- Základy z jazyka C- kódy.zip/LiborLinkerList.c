#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define a node struct that contains an integer value and a pointer to the next node in the list
typedef struct{
    int data;
    struct node* next;
} node;

// Insert a new node with a given value at the beginning of the list
node* NodeInsert(int value, struct node *head){
    // Allocate memory for the new node using malloc and initialize its values
    node* new_node = (node*)malloc(sizeof(node));
    new_node->data = value;
    new_node->next = head;
    // Return the new node as the new head of the list
    return new_node;
}

// Recursively print all the values in the list starting from a given node
void print_list(node* n) {
    // If the current node is NULL, we've reached the end of the list and can stop recursing
    if (n == NULL) {
        printf("List je prazdny"); // Print a message indicating that the list is empty
    } else {
        printf("%d \n", n->data); // Print the value of the current node
        print_list(n->next); // Recursively print the rest of the list starting from the next node
    }
}

int main() {

    node* prvni = NULL;

    prvni = NodeInsert(3, prvni); // Insert a new node with value 3 into the list
    prvni = NodeInsert(4, prvni); // Insert a new node with value 4 into the list
    prvni = NodeInsert(7, prvni); // Insert a new node with value 7 into the list

    print_list(prvni); // Print the entire list starting from the head node

    return 0;
}