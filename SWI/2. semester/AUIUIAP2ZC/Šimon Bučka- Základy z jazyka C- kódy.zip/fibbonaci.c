/**
 * @file main.c
 * @brief A program that calculates the sum of an array, fibonacci and factorial numbers using recursion.
 * 
 */

#include <stdio.h>

/**
 * @brief Calculates a Fibonacci number using recursion
 * 
 * @param index Index of the Fibonacci number to calculate
 * @return int Returns the calculated Fibonacci number
 */
int fibb(int index) {
   if(index == 0){
      return 0;
   } else if(index == 1) {
      return 1;
   } else if(index == 2) {
      return 1;
   } else {
      return (fibb(index-1) + fibb(index-2));
   }
}

/**
 * @brief Calculates the factorial of a given number using recursion
 * 
 * @param index The number to calculate factorial for
 * @return int Returns the calculated factorial
 */
int factorial(int index){
    if(index == 1){
        return 1;
    }
    else{ 
        return index * (factorial(index-1));
    }
}

/**
 * @brief Calculates the sum of an integer array using recursion
 * 
 * @param index The integer array to calculate the sum for
 * @param start Starting index of the array
 * @param lenght Length of the array
 * @return int Returns the sum of the array elements
 */
int suma(int index[],int start,int lenght){
    if(start >=lenght){
        return 0;
    }
    else{
        return (index[start]+suma(index,start+1,lenght));
    }
}

/**
 * @brief Main function where the calculations are performed
 * 
 * @return int Returns 0 on successful execution
 */
int main() {
    int arr1[] = {1,2,3};
    int start = 0;
    int lenght = sizeof(arr1)/sizeof(arr1[0]);

    //calculate the sum of an array
    int sum = suma(arr1,start,lenght);
    printf("\n%d", sum);

    // calculate the Fibonacci number of index 6
    int res = fibb(6);
    printf("\n%d", res);

    //calculate factorial of 4
    int res1 = factorial(4);
    printf("\n%d", res1);
    return 0;
}