#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

// Define a constant length for arrays.
#define LEN_ARR 10

// Define a struct to hold data and its size.
typedef struct {
    int *novepole;
    size_t novaVelikost;
} data;

// Define a function to remove the last element of an array.
int *removeLast(int *arr, int length) {
    // Calculate the size of the new array without the last element.
    size_t sizeToCopy = sizeof(int) * (length - 1);
    // Allocate memory for the new array.
    int *novaPlastelina = malloc(sizeToCopy);
    // Copy all elements except the last one to the new array.
    memcpy(novaPlastelina, arr, sizeToCopy);
    return novaPlastelina;
}

// Define a function to get a subarray from an index n until the end of the array.
int *position(int *arr, int length, int n) {
    // Check if n is an index within the array.
    if (n < length) {
        // Calculate the size of the new array.
        size_t sizeToCopyTo = sizeof(int) * (length - n);
        // Allocate memory for the new array.
        int *novaPlastelina = malloc(sizeToCopyTo);
        // Copy the elements starting from index n to the new array.
        memcpy(novaPlastelina, arr, sizeToCopyTo);
        return novaPlastelina;
    } else {
        // Return NULL if n is not a valid index in the array.
        return NULL;
    }
}

int main() {
    // Create an array of integers.
    int arr[] = {1, 2, 3, 4};
    // Allocate memory for another array of integers.
    int *ukH = malloc(sizeof(int) * LEN_ARR);
    // Populate the allocated array with values.
    for (int i = 0; i < LEN_ARR; ++i) {
        ukH[i] = i + 1;
        printf("%d ", ukH[i]);
    }

    // Call the function to remove the last element of the array.
    int *novepole = removeLast(ukH, LEN_ARR);

    // Check if the allocation was successful.
    if (novepole == NULL) {
        printf("allocation Failed");
        exit(1);
    }

    // Print the resulting subarray starting from index 0.
    for (int i = 0; i < LEN_ARR - 1; ++i) {
        printf("%d ", novepole[i]);
    }

    // Free the allocated memory for both arrays.
    free(novepole);
    free(ukH);
    return 0;
}