/**
* @file main.c
* @brief A program that generates a random array of integers between 1 to 50 and sorts it using bubble sort algorithm.
*
* The program generates an array of 10 random integers between 1 to 50 and sorts them using bubble sort algorithm.
* It then prints the sorted array.
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/**
* @brief Generates a random integer between odKolko and doKolko.
*
* This function uses the rand() function from <stdlib.h> to generate a random integer between odKolko and doKolko.
*
* @param odKolko The lower bound of the range.
* @param doKolko The upper bound of the range.
* @return The randomly generated integer.
*/
int generovanieNahodnehoCislaOdDo(int odKolko, int doKolko){
    return rand() % doKolko + odKolko;
}

/**
* @brief Sorts an array using bubble sort algorithm.
*
* This function implements the bubble sort algorithm to sort the given array in ascending order.
*
* @param arr The array to be sorted.
* @param size The size of the array.
*/
void bubble_sort(int* arr, int size){
    int* arr1[size];
    for(int i ; i < sizeof(arr1) / sizeof(arr1[0]); i++){
        arr1[i] = (&arr[1] + 1);
        printf("%d", arr1[i]);       
    }
}

/**
* @brief The entry point of the program.
*
* This function is the entry point of the program. It generates an array of 10 random integers,
* sorts them using bubble sort algorithm and prints the sorted array.
*
* @return The exit status of the program.
*/
int main() {
    srand(time(0));
    int arr[10];
    int a;
    printf("%s", "Náhodne vygenerované čísla: ");
    for(int i = 0; i < sizeof(arr) / sizeof(arr[0]); i++){
        arr[i] = generovanieNahodnehoCislaOdDo(1, 50);
        printf("%d", arr[i]);
        printf("%s", " ");
    }
    printf("\n%s", "Zoradené čísla: ");    
    bubble_sort(arr, 10);
    for(int i = 1; i < sizeof(arr) / sizeof(arr[0]); i++){
        for(int j = 0; j < sizeof(arr) / sizeof(arr[0]); j++)
        {
            if (arr[j] > arr[j + 1])
            {
                a = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = a;
            }
        }
    } 
    for(int i = 0; i < sizeof(arr) / sizeof(arr[0]); i++){
        printf("%d", arr[i]);
        printf("%s", " ");
    }
    return 0;
}