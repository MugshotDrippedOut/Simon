#include<stdio.h>

// Define the function f(x)
double f (double x){
    return 2*x*x*x-13*x*x-2*x-50;
}

// Define the derivative of f(x), which is needed for Newton's method
double g (double x){
    return 6*x*x-26*x-2;
}

// Implement Newton's method to approximate roots of the equation f(x) = 0
double newton(double x){
    return x-(f(x)/g(x));
}

int main(){
    // Initialize the starting point for Newton's method
    double res = newton(100);
    // Keep track of two separate iterations of Newton's method in order to detect convergence
    double temp = res;
    do{
        // Update res with a single iteration of Newton's method
        res = newton(res);
        // Update temp with two iterations of Newton's method
        temp = newton(newton(temp));
        // Print the current approximation
        printf("%.16f\n",res);
    }while(temp!=res); // Continue until the two iterations coincide (i.e., converge)
    return 0;
}