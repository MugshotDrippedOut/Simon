#include <stdio.h>

int pocetKrokov = 0; // Global variable to keep track of the number of moves

void tower(int pocetKotucov, char from, char to, char help) {
    if (pocetKotucov > 0) { // Base case: stop recursion when there are no disks left to move
        pocetKrokov++; // Increment the move counter
        tower(pocetKotucov - 1, from, help, to); // Move n-1 disks from the "from" peg to the "help" peg
        printf("\nHybem s %d z kolika %c na kolik %c\n", pocetKotucov, from, to); // Move the remaining disk from the "from" peg to the "to" peg
        tower(pocetKotucov - 1, help, to, from); // Move the n-1 disks from the "help" peg to the "to" peg
    }
}

int main() {
    int pocetKotucov = 3; // Set the number of disks to 3
    char kolik1 = 'A'; // Name the first peg "A"
    char kolik2 = 'B'; // Name the second peg "B"
    char kolik3 = 'C'; // Name the third peg "C"
    tower(pocetKotucov, kolik1, kolik3, kolik2); // Call the recursive function to solve the problem
    printf("Celkovo bolo krokov: %d", pocetKrokov); // Print the total number of moves
    return 0;
}