#include <stdio.h>
#include <stdlib.h>

/**
* @brief A structure representing a linked list node.
*/
typedef struct node {
    int data; /**< The integer data stored in the node. */
    struct node* next; /**< Pointer to the next node in the linked list. */
} node;


/**
* @brief Inserts a node at the beginning of a linked list.
* 
* This function creates and inserts a new node with the given value
* at the beginning of the linked list pointed to by prva.
*
* @param value The value to be stored in the new node.
* @param prva A pointer to a pointer to the head of the linked list.
*             This is used to modify the head pointer to reflect the insertion.
*/
/**
* ?The ** in node** prva is a pointer to a pointer. This is used to pass the address of the head pointer of the linked list to the function, so that the function can update the head pointer if a new node is added to the list.
* ?By using **prva, the function can access and modify the value of the pointer to which prvapoints (i.e., the head pointer of the list), rather than just modifying a copy of that pointer. This allows the function to make changes to the original head pointer variable, which will persist beyond the scope of the function.
*/
void NodeInsert(int value, node** prva) {
    node* new_node = (node*)malloc(sizeof(node)); // allocate memory for new node
    new_node->data = value; // set the data value of the new node
    new_node->next = *prva; // set the next pointer of the new node to point to the current head of the list
    *prva = new_node; // update the head pointer to point to the newly inserted node
}



/**
* @brief Calculates the scalar product of two linked lists.
* 
* Given two linked lists n and n1, this function computes their scalar product as follows:
* sum = n[0] * n1[0] + n[1] * n1[1] + ... + n[k] * n1[k], where k is the last common node
* between n and n1.
*
* @param n A pointer to the head of the first linked list.
* @param n1 A pointer to the head of the second linked list.
* 
* @return The computed scalar product of the two linked lists.
*/
int Scalar(node* n, node* n1) {
    int sum = 0;
    while (n != NULL && n1 != NULL) {
        sum += n->data * n1->data;
        n = n->next;
        n1 = n1->next;
    }
    return sum;
}


/**
* @brief A helper function for recursively calculating the scalar product of two linked lists.
* 
* @param n A pointer to the current node of the first linked list.
* @param n1 A pointer to the current node of the second linked list.
* 
* @return The computed scalar product of the two linked lists.
*/
int ScalarUlrich(node* n, node* n1) {
    if (n == NULL || n1 == NULL) {
        return 0;
    }
    return n->data * n1->data + ScalarUlrich(n->next, n1->next);
}


/**
* @brief Computes the dot product between two linked lists recursively.
*
* This function computes the dot product between two linked lists `n` and `n1`
* recursively using the Taylor series approach. The dot product is computed as 
* the sum of products of corresponding nodes in both linked lists. The function 
* expects pointers to the heads of the linked lists, `n` and `n1`, along with 
* an integer variable `sum` to keep track of the sum of products.
*
* @param n A pointer to the head of the first linked list.
* @param n1 A pointer to the head of the second linked list.
* @param sum An integer variable that keeps track of the sum of products.
* @return The dot product of the two linked lists.
*/
int ScalarTaylor(node* n, node* n1, int sum) {
    // If either linked list is empty, return the sum of products computed so far
    if (n == NULL || n1 == NULL) {
        return sum;
    }
    // Otherwise, add the product of the current nodes to the sum and recurse
    else {
        sum += ((n->data) * (n1->data));
        return ScalarTaylor(n->next, n1->next, sum);
    }
}


/**
* @brief Prints the elements of a linked list.
* 
* @param n A pointer to the head of the linked list.
*/
void print_list(void* n) {
    struct node* curr = (struct node*)n;
    while (curr != NULL) {
        printf("%d ", curr->data);
        curr = curr->next;
    }
    printf("STOP\n");
}


/**
* @brief Main function that sets up two linked lists, computes their scalar 
* product using three different methods/functions, and prints the results.
* 
* @return int Returns 0 on success.
*/
int main() {
    // Set up first linked list
    node* prva = NULL;
    NodeInsert(8, &prva);
    NodeInsert(4, &prva);
    NodeInsert(3, &prva);
    NodeInsert(11, &prva);
    print_list(prva);

    // Set up second linked list
    node* prva1 = NULL;
    NodeInsert(10, &prva1);
    NodeInsert(5, &prva1);
    NodeInsert(15, &prva1);
    NodeInsert(5, &prva1);
    print_list(prva1);

    // Compute scalar product using three different methods/functions
    int sum = Scalar(prva, prva1);
    int sumUlrich = ScalarUlrich(prva, prva1);
    int sumTaylor = ScalarTaylor(prva, prva1, 0);

    // Print the computed scalar products
    printf("\n%d Scalar", sum);
    printf("\n%d ScalarUlrich", sumUlrich);
    printf("\n%d ScalarTaylor", sumTaylor);

    return 0;
}