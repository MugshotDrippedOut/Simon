/**
 * @file main.c
 * @brief A program that demonstrates the use of a singly linked list.
 */

#include <stdio.h>
#include <stdlib.h>

/**
 * @struct node
 * @brief A struct that represents a node in a singly linked list
 */
struct node{
    int data; /**< The integer value stored in the node */
    struct node* aktualne; /**< A pointer to the next node in the list */
};

struct node* predchadzajuce=NULL; /**< A global pointer to the head of the list */

/**
 * @brief Inserts a new node with a given value at the head of the list
 * @param value The integer value to be stored in the new node
 * @return A pointer to the newly created node
 */
struct node* insert(int value){
    struct node* novyNode=(struct node*)malloc(sizeof(struct node));
    novyNode->data=value;
    novyNode->aktualne=predchadzajuce;
    predchadzajuce=novyNode;
    return novyNode;
}

/**
 * @brief The entry point of the program
 * @return Exit status of the program
 */
int main(){
    insert(2);
    insert(7);
    insert(5);
    insert(3);
    struct node* node1=predchadzajuce;
    while(node1 !=NULL){
        printf("%d ",node1->data);
        node1 = node1->aktualne;
    }
    return 0;
}