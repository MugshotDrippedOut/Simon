# TW úkol
- Téma: HRY
- Podstránky: 
    - Úvodní stránka
    - Galerie
    - Trailery
    - Obchod
    - Recenze

![alt](stranka.excalidraw.png)