# Library ioutils

This is a simple library that helps with reading data from the user. It is designed to safe reading values from user in specified format. The reading is done by line, that is then parsed into desired format. The format can be specified or you can use predefined helper functions for quick reading of the basic types. The reading is repeated if the loaded value does not match with the requested type.

## Usage

```c
#include "ioutils.h"

int main(void){
    long longVal;
    if(io_utils_get_long(&longVal)){
        printf("Loaded value %ld\n", longVal);
    }
    
    char c;
    float f;
    int hex;
    
    if(io_utils_get("%c %f %x", &c, &f, &hex)){
        printf("More complex example: %c %f %x\n", c, f, hex);
    }
    
    return 0;
}
```
