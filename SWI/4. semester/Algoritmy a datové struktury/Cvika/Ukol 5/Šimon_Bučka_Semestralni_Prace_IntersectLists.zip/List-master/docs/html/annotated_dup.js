var annotated_dup =
[
    [ "Data_t", "struct_data__t.html", "struct_data__t" ],
    [ "List_Node_s", "struct_list___node__s.html", "struct_list___node__s" ],
    [ "List_t", "struct_list__t.html", "struct_list__t" ]
];