var searchData=
[
  ['name_31',['name',['../struct_data__t.html#a6db5324e662b3f6727875212f7aa6359',1,'Data_t']]],
  ['next_32',['next',['../struct_list___node__s.html#a512dc8c6be527ab6ea0e050ff8ff355f',1,'List_Node_s']]]
];
