var searchData=
[
  ['weight_33',['weight',['../struct_data__t.html#a99108733d00274978a4979dc072bd513',1,'Data_t']]]
];
