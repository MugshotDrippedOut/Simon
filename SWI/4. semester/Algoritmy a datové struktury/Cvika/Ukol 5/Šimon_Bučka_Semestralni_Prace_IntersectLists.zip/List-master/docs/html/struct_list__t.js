var struct_list__t =
[
    [ "active", "struct_list__t.html#afe958fb464d8e90a2edd6498f8d1263f", null ],
    [ "first", "struct_list__t.html#a99e3dbd373e3dc46d3aeec5f3ca108a0", null ]
];