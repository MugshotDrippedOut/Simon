var group__list =
[
    [ "List_Node_s", "struct_list___node__s.html", [
      [ "data", "struct_list___node__s.html#a5a4fa152238036970f620343941e72c4", null ],
      [ "next", "struct_list___node__s.html#a512dc8c6be527ab6ea0e050ff8ff355f", null ]
    ] ],
    [ "List_t", "struct_list__t.html", [
      [ "active", "struct_list__t.html#afe958fb464d8e90a2edd6498f8d1263f", null ],
      [ "first", "struct_list__t.html#a99e3dbd373e3dc46d3aeec5f3ca108a0", null ]
    ] ],
    [ "List_Node_Ptr_t", "group__list.html#gacf6bb6d04e407100c3f52f9836af1dab", null ],
    [ "List_Node_t", "group__list.html#ga6c765786e85f08f36b96f447a6343370", null ],
    [ "List_Active_Next", "group__list.html#ga8018301f34918c29ca7d10bcc4156d4f", null ],
    [ "List_Active_Update", "group__list.html#gaefb7c3186ae3400627bda37ea974e297", null ],
    [ "List_Copy", "group__list.html#ga4c8f7aa9af80f49485b740dbb7759d93", null ],
    [ "List_Copy_First", "group__list.html#ga1bbc786b44a9421e7267674e49c3f3e8", null ],
    [ "List_Delete_First", "group__list.html#ga400926d0e75ee7827a7debeb188f5cdf", null ],
    [ "List_First", "group__list.html#ga6307579b1f9e7d65bdb8e359e6ee84d3", null ],
    [ "List_Init", "group__list.html#gace09326596b9f273799f108cd94f6305", null ],
    [ "List_Insert_First", "group__list.html#gabfb0e3cd31e9c01927b84d19d97aac08", null ],
    [ "List_Is_Active", "group__list.html#ga620f33db96a73710602ac564f6ac05eb", null ],
    [ "List_Post_Delete", "group__list.html#ga65ba2ce340038176e714401dee8d5940", null ],
    [ "List_Post_Insert", "group__list.html#gabafdec67bfc128bea7e0a184f41851d1", null ]
];