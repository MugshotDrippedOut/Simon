var searchData=
[
  ['vector_5fdatatype_5ft_49',['Vector_DataType_t',['../group__vector.html#gaa721ee7a4c78a42133d8b7881fea3e76',1,'vector.h']]]
];
