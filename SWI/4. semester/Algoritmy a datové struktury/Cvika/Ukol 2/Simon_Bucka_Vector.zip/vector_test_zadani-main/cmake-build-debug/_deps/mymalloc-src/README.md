# Library myMalloc

This is a simple library that helps with dynamic memory operations. It wraps around standard calls and monitors the allocation, reallocation, and free requests. It helps with the tracking of memory leaks and users can see how expensive is their implementation.

The library logs each memory request in the internal hash map. The returned pointer and requested size is stored in the map for statistical needs. The log messages are displyed only in the debug build, in release build, the library is simple wrapper around standard calls.
